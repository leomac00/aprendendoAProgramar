class Bubble {
  constructor() {
    var topSpeed = 15;
    var minSpeed = 0.1;
    this.x = random(width);
    this.y = random(height);
    this.xspeed = random(minSpeed, topSpeed);
    this.yspeed = random(minSpeed, topSpeed);
    this.size = random(50, 150);
    this.r = random(255);
    this.g = random(255);
    this.b = random(255);
  }

  move() {
    this.y += this.yspeed;
    this.x += this.xspeed;
    if (this.x > width || this.x < 0) {
      this.xspeed = -this.xspeed
      }
    if (this.y > height || this.y < 0) {
      this.yspeed = -this.yspeed
    }
  }

  show() {
    noStroke();
    fill(this.r, this.b, this.b);
    ellipseMode(CENTER)
    ellipse(this.x, this.y, this.size, this.size);
  }
}