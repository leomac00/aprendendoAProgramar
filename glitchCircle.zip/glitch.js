class GC {
  constructor(firstx, firsty, radius) {
    this.x = firstx;
    this.y = firsty;
    this.radius = radius;
    this.jitterSpec = 6.5;
    this.thickness = 3;
    this.yspeed = map(mouseY, 0, height, -10, 10);
    this.xspeed = map(mouseX, 0, width, -10, 10);
  }

  move() {
    //Movement
    this.x += random(-this.jitterSpec, this.jitterSpec) + this.xspeed;
    this.y += random(-this.jitterSpec, this.jitterSpec) + this.yspeed;

    //Horizontal Bounce
    if (this.x >= width) {
      this.xspeed = -this.xspeed;
    }

    if (this.x <= 0) {
      this.xspeed = -this.xspeed;
    }

    //Vertical reset
    if (this.y >= height) {
      this.yspeed = -this.yspeed;
    }
    if (this.y <= 0) {
      this.yspeed = -this.yspeed;
    }
  }

  displayCirc() {
    noFill();
    ellipseMode(CENTER);
    strokeWeight(this.thickness);
    //White Circle layer
    stroke(255);
    ellipse(this.x, this.y, this.radius);
    //Red circle layer
    stroke(204, 15, 57, 175);
    ellipse(this.x + random(-this.jitterSpec, this.jitterSpec), this.y + random(-this.jitterSpec, this.jitterSpec), this.radius);
    //Blue circle layer    
    stroke(15, 251, 249, 175);
    ellipse(this.x + random(-this.jitterSpec, this.jitterSpec), this.y + random(-this.jitterSpec, this.jitterSpec), this.radius);

  }





}