var len = 10;
var bubbles = [];
function setup() {
  createCanvas(700, 500);

  for (var i = 0; i < len; i++) {
    bubbles[i] = new Bubble;
  }
}

function draw() {
  background(0);
  
  for (var i = 0; i < len; i++) {
    bubbles[i].move();
    bubbles[i].show()
    
  }
}
