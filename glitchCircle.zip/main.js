var obj = [];

function setup() {
  createCanvas(600, 400);
  let newItem = new GC(width / 2, height / 2, 200);
  obj.push(newItem);
  // background(0);
}

function draw() {
  background(0);
  for (let i = 0; i < obj.length; i++) {
    obj[i].displayCirc();
    obj[i].move();
  };

}

function mousePressed() {
  let v = new GC(mouseX, mouseY, 50)
  obj.push(v);
}