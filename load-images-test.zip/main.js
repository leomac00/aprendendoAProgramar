var obj = [];

function setup() {
  // frameRate(10);
  createCanvas(600, 400);
  for (let i = 0; i < 5; i++) {
    let newItem = new GC(random(width), random(height), 50);
    obj.push(newItem);
  }
  // background(0);
}

function draw() {
  background(0);
  for (let i = 0; i < obj.length; i++) {
    obj[i].showKitten();
    obj[i].move();
  };
  if (obj.length > 5) {
    obj.splice(0, 1)
  }
}

function mouseDragged() {
  let b = new GC(mouseX, mouseY, 50)
  obj.push(b)
}

function mousePressed() {
  let v = new GC(mouseX, mouseY, 50)
  obj.push(v);
}