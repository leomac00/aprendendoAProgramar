var gotas = [];

function setup() {
  createCanvas(600, 400);
  for (let i = 0; i < 250; i++) {
    gotas[i] = new Drop;
  }
}


function draw() {
  background(200);
  for (let i = 0; i < gotas.length; i++) {
    gotas[i].rain();
    gotas[i].show();
  }
}