class Drop {
  constructor() {
    this.x = random(width);
    this.y = random(-height / 2, 0);
    this.z = random(50);
    this.fallSpeed = map(this.z, 0, 50, 10, 3);
  }

  rain() {
    this.y += this.fallSpeed
    if (this.y >= height) {
      this.y = random(-height / 2, 0);
      this.x = random(width); 
    }
  }

  show() {
    strokeWeight(3);
    stroke(138, 43, 226);
    line(this.x, this.y, this.x, this.y + (map(this.fallSpeed, 10, 3, 10, 2)));
  }

}